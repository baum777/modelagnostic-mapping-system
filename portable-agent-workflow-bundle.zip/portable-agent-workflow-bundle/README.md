# Portable Agent Workflow Bundle

This bundle packages a full cross-provider planning and implementation handover for evolving a Codex-centered workflow repository into a provider-neutral agent workflow core with provider adapters for:

- OpenAI / Codex / GPT
- Anthropic Claude
- Qwen Code / Qwen-Agent
- Kimi K2.5

## Bundle contents

### Docs
- `docs/architecture-spec.md`
- `docs/repo-target-structure.md`
- `docs/provider-capability-matrix.md`
- `docs/migration-roadmap.md`

### Prompt bundles
- `prompts/planning/gpt54-mini-planning-prompt.md`
- `prompts/planning/gpt54-mini-planning-prompt.txt`
- `prompts/implementation/gpt54-mini-implementation-prompt.md`
- `prompts/implementation/gpt54-mini-implementation-prompt.txt`
- `prompts/implementation/follow-up-implementation-review-prompt.md`

### Contracts
- `contracts/portable-skill-contract.example.json`
- `contracts/tool-contract.example.json`
- `contracts/provider-capability-matrix.example.json`
- `contracts/output-contract-index.md`

### Examples
- `examples/use-case-to-skill-mapping.md`

## Intended use

### Planning phase
Use the planning prompt first to:
- audit the current repo
- classify portable vs provider-specific surfaces
- define the target architecture
- produce the migration plan
- define contracts, evals, and provider mappings

### Implementation phase
Use the implementation prompt only after the planning output is accepted. It is intended to:
- transform the repo structure
- extract portable core assets
- add provider adapters
- normalize tool contracts
- introduce evals and export paths
- preserve boundaries and governance

### Review phase
Use the follow-up implementation review prompt to verify:
- no authority or boundary drift
- no accidental provider lock-in in core
- no missing contracts or exports
- no incomplete eval gating

## Recommended execution order
1. Read `docs/architecture-spec.md`
2. Run `prompts/planning/gpt54-mini-planning-prompt.txt`
3. Review and lock target decisions
4. Run `prompts/implementation/gpt54-mini-implementation-prompt.txt`
5. Run `prompts/implementation/follow-up-implementation-review-prompt.md`

## Design assumptions
- The repository currently has strong governance and useful workflow assets.
- The main issue is over-coupling to Codex/OpenAI-specific packaging and identity.
- The correct next step is refactoring into a provider-neutral core plus provider-specific adapters.
- Skills remain the top-level portable workflow abstraction.
- Tool contracts, output contracts, and evals become first-class release surfaces.

