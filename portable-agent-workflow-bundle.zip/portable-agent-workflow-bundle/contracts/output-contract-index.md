# Output Contract Index

## Initial output contracts
- `audit-report-v1`
- `readiness-report-v1`
- `migration-plan-v1`
- `research-synthesis-v1`
- `knowledge-asset-v1`
- `handover-spec-v1`
- `tool-audit-v1`
- `prompt-architecture-spec-v1`
- `bundle-spec-v1`
- `ci-triage-report-v1`

## Contract rules
- version every contract
- keep contract names provider-neutral
- define required sections or fields explicitly
- use contracts as parity baselines across provider exports
