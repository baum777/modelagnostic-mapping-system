# Use-Case to Skill Mapping

| Use Case | Portable Skill | Typical Tools | Output Contract |
|---|---|---|---|
| UC-01 Repo audit and architecture understanding | `repo-audit` | file reader, repo search, tree inspector | `audit-report-v1` |
| UC-02 Readiness and debugging | `readiness-check` | logs, env parser, test runner | `readiness-report-v1` |
| UC-03 Prompt and agent system design | `prompt-system-architect` | docs search, contract reader | `prompt-architecture-spec-v1` |
| UC-04 Research and synthesis | `research-synthesis` | web search, doc fetch, source reader | `research-synthesis-v1` |
| UC-05 Long documents and transcripts | `long-document-to-knowledge-asset` | file reader, chunking, summarizer | `knowledge-asset-v1` |
| UC-06 Structured handovers and bundles | `handover-writer` / `checklist-and-bundle-builder` | structured writer, templates | `handover-spec-v1` / `bundle-spec-v1` |
