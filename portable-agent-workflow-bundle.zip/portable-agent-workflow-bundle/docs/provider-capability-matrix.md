# Provider Capability Matrix

## Goal
This matrix documents how the shared portable workflow core should map into each provider ecosystem.

| Dimension | OpenAI / Codex | Claude | Qwen Code | Kimi K2.5 |
|---|---|---|---|---|
| Best high-level fit | project guidance + skills + subagents | skills + commands + subagents + hooks | extensions + skills + subagents + commands | tool templates + JSON mode + search |
| Core guidance surface | `AGENTS.md` | project guidance + commands | extension docs + commands | system prompt/template |
| Native or primary skill surface | strong | strong | strong | indirect / template-oriented |
| Subagent support style | explicit | explicit | explicit | more orchestration-oriented |
| MCP alignment | yes | yes | yes | yes / adaptable |
| Structured outputs | yes | yes | yes | especially important |
| Tool schema emphasis | high | high | high | very high |
| Best packaging target | skill bundle | skill module / command package | extension | tool-agent template |
| Repo-audit fit | excellent | excellent | excellent | good |
| Research-synthesis fit | strong | strong | strong | excellent |
| Long-document transformation fit | strong | strong | good | strong |
| Checklist/bundle output fit | strong | strong | good | strong |
| Main caveat | avoid Codex identity leakage into core | avoid overusing subagents | extension packaging adds complexity | less skill-native, more tool-centric |

## Use-case fit summary

### Best reference platform for designing the shared core
- OpenAI / Codex

### Best complementary platform for codebase work and controlled delegation
- Claude

### Best platform for packaged reusable workflow extensions
- Qwen Code

### Best complementary platform for tool-heavy search/research/JSON workflows
- Kimi K2.5
