# Repository Target Structure

## Recommended structure

```text
repo/
  core/
    skills/
      repo-audit/
        skill.md
        portability.json
        output-contract.json
        evals/
      readiness-check/
      migration-planner/
      research-synthesis/
      long-document-to-knowledge-asset/
      handover-writer/
      tool-contract-auditor/
      prompt-system-architect/
      checklist-and-bundle-builder/
      test-and-ci-triage/

    output-contracts/
      audit-report-v1.json
      readiness-report-v1.json
      migration-plan-v1.json
      research-synthesis-v1.json
      knowledge-asset-v1.json
      handover-spec-v1.json
      tool-audit-v1.json
      prompt-architecture-spec-v1.json
      bundle-spec-v1.json
      ci-triage-report-v1.json

    tool-contracts/
      catalog.json
      schemas/
      approval-matrix.json

    overlays/
      local-input-contract.schema.json
      runtime-policy-input.schema.json

    evals/
      routing/
      schema/
      tool-selection/
      boundary/
      provider-parity/
      failure-modes/

    docs/
      skill-authoring-guide.md
      tool-authoring-guide.md
      portability-matrix.md

  providers/
    openai-codex/
      agents/
      skills/
      subagents/
      export-maps/
      notes.md

    anthropic-claude/
      skills/
      commands/
      subagents/
      hooks/
      export-maps/
      notes.md

    qwen-code/
      extensions/
      skills/
      subagents/
      commands/
      export-maps/
      notes.md

    kimi-k2_5/
      templates/
      tools/
      json-mode/
      export-maps/
      notes.md

  scripts/
    validate/
      validate-skill-contracts.mjs
      validate-tool-contracts.mjs
      validate-output-contracts.mjs
    export/
      export-codex.mjs
      export-claude.mjs
      export-qwen.mjs
      export-kimi.mjs
    eval/
      run-routing-evals.mjs
      run-schema-evals.mjs
      run-boundary-evals.mjs
      run-provider-parity.mjs

  examples/
    portable/
      use-case-to-skill-mapping.md
    provider-mapped/
      codex-example.md
      claude-example.md
      qwen-example.md
      kimi-example.md

  docs/
    architecture-spec.md
    migration-roadmap.md
    provider-capability-matrix.md
```

## Folder design rules

### `core/`
Provider-neutral only.

### `providers/`
No canonical workflow truth here. Adapter/export only.

### `scripts/`
Validation, export, and eval automation only.

### `examples/`
Derived and instructional, never canonical source-of-truth.

### `docs/`
Canonical narrative documentation.
