# Migration Roadmap

## Phase 1 — Architecture Lock
### Goal
Freeze target terminology, scope, and layer boundaries.

### Deliverables
- architecture-spec.md approved
- target folder structure approved
- provider capability matrix approved
- first-wave skill list approved

### Risks
- ambiguous ownership of core vs provider logic
- trying to implement before contracts are stable

---

## Phase 2 — Contract Extraction
### Goal
Define portable contracts before moving files.

### Deliverables
- portable skill contract schema
- tool contract schema
- output contract index
- provider capability contract

### Risks
- overfitting contracts to current Codex layout
- under-specifying approval behavior

---

## Phase 3 — Core Normalization
### Goal
Move shared logic into provider-neutral locations and names.

### Deliverables
- `core/skills/`
- `core/tool-contracts/`
- `core/output-contracts/`
- `core/evals/`

### Risks
- hidden provider assumptions in filenames or metadata
- path breakage if scripts or docs are not updated

---

## Phase 4 — Provider Adapter Introduction
### Goal
Add provider-specific export surfaces.

### Deliverables
- `providers/openai-codex/`
- `providers/anthropic-claude/`
- `providers/qwen-code/`
- `providers/kimi-k2_5/`

### Risks
- mixing adapter-specific logic back into the core
- undocumented capability gaps

---

## Phase 5 — Eval Layer Activation
### Goal
Make skills releasable only with required eval coverage.

### Deliverables
- routing evals
- schema evals
- tool-selection evals
- boundary evals
- provider parity evals
- failure-mode evals

### Risks
- too little test coverage
- vague pass/fail criteria

---

## Phase 6 — Secondary Skill Migration
### Goal
Port remaining use-case families after first-wave stabilization.

### Deliverables
- handover-writer
- tool-contract-auditor
- prompt-system-architect
- checklist-and-bundle-builder
- test-and-ci-triage

---

## Phase 7 — Documentation Convergence
### Goal
Bring all docs, examples, and onboarding surfaces into alignment.

### Deliverables
- updated README
- skill authoring guide
- tool authoring guide
- portability matrix
- example exports
