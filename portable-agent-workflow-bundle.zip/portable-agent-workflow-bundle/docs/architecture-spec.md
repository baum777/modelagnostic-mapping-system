# Architecture Spec: Portable Agent Workflow Core with Provider Adapters

## 1. Purpose

This document defines the target architecture for transforming a Codex-centered workflow repository into a provider-neutral agent workflow core with provider-specific adapters and exports.

The target system should preserve:
- strong workflow governance
- explicit boundaries
- reusable skills
- deterministic or audit-friendly execution guidance where applicable
- compatibility with multiple agent-capable model ecosystems

The target system should eliminate or reduce:
- provider identity leakage into the shared core
- packaging-specific logic mixed with workflow intent
- implicit tool permissions
- free-form output drift for critical workflows
- missing evaluation and release criteria

---

## 2. Strategic Architecture Decision

### Decision
The repository should become **provider-neutral in the core** and **provider-specific only in adapter and export layers**.

### Rationale
The main differentiator across Codex, Claude, Qwen, and Kimi is no longer the high-level workflow logic itself. The differences now mostly appear in:
- packaging format
- skill and command distribution surfaces
- tool-call interfaces and schema handling
- MCP wiring and extension surfaces
- project-level guidance conventions

This means the repository should not be designed as four separate prompt libraries. It should be designed as one portable workflow core that can be projected into several provider-native forms.

---

## 3. Architectural Principles

### 3.1 Portable core first
All reusable workflow logic should live in a provider-neutral core.

### 3.2 Provider adapters, not provider forks
Provider-specific behaviors should be isolated to thin adapter/export layers.

### 3.3 Skills remain the top-level portable abstraction
A skill represents a reusable unit of work, not a specific packaging format.

### 3.4 Tool contracts are schema-first
Tools must be defined through structured contracts, not prose-only descriptions.

### 3.5 Output contracts are mandatory for critical workflows
High-value workflows must emit structured, reviewable outputs.

### 3.6 Approval boundaries are explicit
Every skill and tool must declare mutation level and approval mode.

### 3.7 Evals are part of the architecture
A skill is not complete unless routing, schema, tool, boundary, and failure-mode behavior are testable.

### 3.8 Core must remain provider-neutral in naming and identity
No provider-branded identity should dominate the core layer.

---

## 4. Current-State Diagnosis

### Observed pattern
The current repo already appears strong in:
- governance-minded documentation
- compatibility discipline
- skill-style decomposition
- local input and overlay contracts
- reusable audit and planning surfaces
- canonical vs derived thinking

### Primary architectural issue
The main weakness is identity and packaging coupling:
- Codex/OpenAI-oriented packaging appears too central
- provider-specific assumptions risk leaking into core abstractions
- export/distribution surfaces are not yet cleanly separated from workflow intent

### Interpretation
This is not a failing architecture. It is an architecture at the point where it needs **decoupling and normalization**, not replacement.

---

## 5. Core Design Layers

## 5.1 Layer A — Portable Workflow Core
This layer contains everything that should remain stable across providers.

### Includes
- portable skill definitions
- skill metadata and routing hints
- output contract definitions
- tool contract definitions
- approval and mutation rules
- use-case taxonomy
- eval definitions
- overlay and local input schemas
- architecture and governance docs

### Must not include
- provider-specific plugin manifests
- provider-specific extension packaging
- provider-specific brand naming in canonical asset IDs
- provider-specific command syntax in the canonical contract layer

---

## 5.2 Layer B — Provider Adapters
This layer maps portable core artifacts into provider-native forms.

### Includes
- Codex/OpenAI exports
- Claude exports
- Qwen exports
- Kimi exports
- provider-specific notes and caveats
- provider-specific configuration fragments

### Responsibilities
- transform portable skill metadata into provider-native packaging
- bind tool contracts to provider-native tool systems
- bind output contracts to provider-native structured output expectations
- expose capability differences cleanly without polluting the core

---

## 5.3 Layer C — Runtime / Tool Transport Layer
This layer handles connection and transport surfaces.

### Includes
- MCP mappings
- tool schemas
- connector assumptions
- command wrappers
- execution shell notes
- approval-mode bridges

### Design rule
This layer should be independent from business intent. It exists to connect workflows to tools safely.

---

## 5.4 Layer D — Eval / Certification Layer
This layer determines whether assets are complete and releasable.

### Includes
- routing evals
- output schema evals
- tool selection evals
- approval and boundary evals
- provider parity evals
- failure-mode evals
- release gates

### Design rule
No skill should be considered production-ready without passing required eval classes.

---

## 6. Use-Case Families

The shared core should be organized around use-case families rather than providers.

### UC-01 Codebase and architecture understanding
- repo audit
- structure mapping
- governance analysis
- canonical vs derived classification

### UC-02 Technical readiness and debugging
- startup blockers
- config/env analysis
- test gap analysis
- CI triage

### UC-03 Prompt, skill, and agent system design
- prompt architecture
- skill system design
- tool contract design
- routing and boundary logic

### UC-04 Research and synthesis
- documentation comparison
- official-docs-first synthesis
- web research
- provider comparison

### UC-05 Long document transformation
- transcript summarization
- PDF extraction
- checklist generation
- concept derivation

### UC-06 Structured deliverables
- handover specs
- executive summaries
- bundle/checklist creation
- application or concept documents

---

## 7. Portable Skill System

## 7.1 Normative skill contract
Each skill must declare at least:
- `skill_id`
- `portable_intent`
- `use_cases`
- `inputs`
- `required_tools`
- `optional_tools`
- `subagent_policy`
- `approval_mode`
- `output_contract`
- `eval_suite`
- `provider_projection`

### Example fields
- `subagent_policy` must be explicit
- `approval_mode` must be explicit
- `provider_projection` must be metadata only, not the core skill body

## 7.2 First-wave skills
The initial portable library should include:
- `repo-audit`
- `readiness-check`
- `migration-planner`
- `research-synthesis`
- `long-document-to-knowledge-asset`
- `handover-writer`
- `tool-contract-auditor`
- `prompt-system-architect`
- `checklist-and-bundle-builder`
- `test-and-ci-triage`

---

## 8. Tool Contract Strategy

### Mandatory fields
Each tool contract should include:
- `tool_name`
- `intent_class`
- `schema`
- `side_effects`
- `approval_required`
- `mcp_compatible`
- `providers`
- `routing_hints`

### Required classifications
Every tool must classify:
- read-only vs mutating
- destructive vs non-destructive
- approval requirements
- provider support expectations

### Design rules
- tools must be machine-readable
- tools must support linting and validation
- tools must not rely only on narrative descriptions

---

## 9. Output Contract Strategy

Critical workflows require structured outputs.

### Initial output contracts
- `audit-report-v1`
- `readiness-report-v1`
- `migration-plan-v1`
- `research-synthesis-v1`
- `knowledge-asset-v1`
- `handover-spec-v1`
- `tool-audit-v1`
- `prompt-architecture-spec-v1`
- `bundle-spec-v1`
- `ci-triage-report-v1`

### Design rules
- contracts should be versioned
- contracts should be review-friendly
- contracts should enable provider parity testing

---

## 10. Provider Adapter Model

## 10.1 OpenAI / Codex adapter
### Best fit
- `AGENTS.md`
- Skills
- Subagents
- versioned bundles
- deterministic helper scripts where useful

### Adapter role
- map core skills into Codex skill format
- integrate routing hints with project guidance
- expose optional subagent profiles

## 10.2 Claude adapter
### Best fit
- Skills
- Commands
- Subagents
- Hooks
- Tool use / MCP

### Adapter role
- map core skills into Claude-friendly skill modules
- provide custom command equivalents where beneficial
- define narrow subagent projections

## 10.3 Qwen adapter
### Best fit
- Extensions
- Skills
- Subagents
- Commands
- MCP

### Adapter role
- package core skills into extension-oriented distributions
- include commands and subagent configs where helpful

## 10.4 Kimi adapter
### Best fit
- tool-call-first templates
- JSON output modes
- search and tool orchestration
- MCP-aligned setups

### Adapter role
- project core skills into agent templates
- enforce schema-first outputs
- bind research and structured-deliverable flows to tools

---

## 11. Target Repository Structure

```text
repo/
  core/
    skills/
    output-contracts/
    tool-contracts/
    overlays/
    evals/
    docs/

  providers/
    openai-codex/
    anthropic-claude/
    qwen-code/
    kimi-k2_5/

  scripts/
    validate/
    export/
    eval/

  examples/
    portable/
    provider-mapped/

  docs/
    architecture.md
    migration-roadmap.md
    portability-matrix.md
    provider-capability-matrix.md
```

### Design rule
The repository should be understandable from top to bottom without requiring prior knowledge of any single provider ecosystem.

---

## 12. Eval and Release Model

### Mandatory eval classes
- routing
- schema
- tool-selection
- approval-boundary
- provider-parity
- failure-mode

### Release blockers
- missing output contract
- invalid tool contract
- unclassified mutation behavior
- missing provider projection for intended exports
- schema failures on golden tasks
- boundary violations

### Advisory-only issues
- style differences across providers
- verbosity drift without semantic drift
- noncritical formatting variation

---

## 13. Migration Strategy

### Phase 1 — Architecture lock
Lock target architecture, contracts, terminology, and provider boundaries.

### Phase 2 — Contract extraction
Extract portable skill contracts, tool contracts, output contracts, and capability matrix.

### Phase 3 — Core normalization
Move provider-specific identities out of the core and normalize names and paths.

### Phase 4 — Provider adapter introduction
Create export surfaces for Codex, Claude, Qwen, and Kimi.

### Phase 5 — Eval layer activation
Introduce required eval suites and release criteria.

### Phase 6 — Secondary skill migration
Port remaining workflows and examples.

### Phase 7 — Documentation convergence
Update architecture docs, examples, and onboarding guidance.

---

## 14. Architecture Decisions to Lock First

1. The core becomes provider-neutral.
2. Skills remain the top-level portable workflow abstraction.
3. Tool contracts become schema-first and approval-aware.
4. Provider packaging moves out of the core into adapter/export layers.
5. Required eval suites become part of the definition of done.

---

## 15. Final Verdict

The correct next step is not to abandon the current repository model. The correct next step is to refactor it into a **portable workflow core** with **provider adapters**, while preserving its strongest existing properties: governance discipline, reusable workflows, structured thinking, and strong boundaries.
