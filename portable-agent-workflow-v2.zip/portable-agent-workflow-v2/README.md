# Portable Agent Workflow Core v2

This bundle is a strict repo-ready canonical starter for a provider-neutral agent workflow core.

## Included
- `docs/architecture-spec.md` — canonical architecture specification
- `docs/repo-target-structure.md` — target repository layout and migration notes
- `docs/use-case-to-skill-mapping.md` — use case matrix and provider adaptations
- `prompts/planning-prompt-gpt5.4-mini.md` — planning prompt
- `prompts/implement-prompt-gpt5.4-mini.md` — implementation prompt
- `prompts/final-review-prompt-gpt5.4-mini.md` — review prompt
- `contracts/` — canonical contracts and schemas
- `core/skills/` — portable skill shells with portability metadata
- `providers/` — provider adapter notes
- `evals/` — eval placeholders and categories
- `scripts/` — starter validation/export scripts placeholders

## Canonical principles
1. Core is provider-neutral.
2. Skills are portable workflow units.
3. Tool contracts are schema-first and approval-aware.
4. Output contracts are explicit and versioned.
5. Provider-specific packaging lives behind adapters.
6. Every skill requires eval coverage.

## Intended workflow
1. Run planning prompt against current repo.
2. Produce architecture lock and migration plan.
3. Execute implementation prompt in phased slices.
4. Run final review prompt for convergence and gap closure.
