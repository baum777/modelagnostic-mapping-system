# Provider notes — openai-codex

This folder is an adapter surface only.
Do not redefine core intent here.
Only place provider-specific packaging, caveats, export maps, and usage notes here.
