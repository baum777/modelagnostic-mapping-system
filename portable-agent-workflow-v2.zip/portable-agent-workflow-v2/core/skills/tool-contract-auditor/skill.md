# tool-contract-auditor

## Portable intent
Audit tool surfaces, approvals, and compatibility metadata.

## Use when
- See portability.json

## Do not use when
- A simpler or narrower skill fully covers the task

## Output
- `tool-audit-v1`
