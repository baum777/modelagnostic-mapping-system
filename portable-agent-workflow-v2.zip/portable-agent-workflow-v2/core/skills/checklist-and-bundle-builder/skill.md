# checklist-and-bundle-builder

## Portable intent
Build structured checklists, bundles, and document packs.

## Use when
- See portability.json

## Do not use when
- A simpler or narrower skill fully covers the task

## Output
- `bundle-spec-v1`
