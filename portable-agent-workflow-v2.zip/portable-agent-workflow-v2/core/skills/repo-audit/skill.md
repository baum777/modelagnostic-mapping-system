# repo-audit

## Portable intent
Analyze a repository structure, governance, risks, and implementation gaps.

## Use when
- See portability.json

## Do not use when
- A simpler or narrower skill fully covers the task

## Output
- `audit-report-v1`
