# migration-planner

## Portable intent
Produce phased migration and refactor plans.

## Use when
- See portability.json

## Do not use when
- A simpler or narrower skill fully covers the task

## Output
- `migration-plan-v1`
