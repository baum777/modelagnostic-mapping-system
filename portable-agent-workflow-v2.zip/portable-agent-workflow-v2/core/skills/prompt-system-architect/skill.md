# prompt-system-architect

## Portable intent
Design prompt, skill, and workflow architectures.

## Use when
- See portability.json

## Do not use when
- A simpler or narrower skill fully covers the task

## Output
- `prompt-architecture-spec-v1`
