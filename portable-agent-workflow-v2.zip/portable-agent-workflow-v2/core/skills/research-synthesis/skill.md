# research-synthesis

## Portable intent
Collect and synthesize official and community sources into a grounded report.

## Use when
- See portability.json

## Do not use when
- A simpler or narrower skill fully covers the task

## Output
- `research-synthesis-v1`
