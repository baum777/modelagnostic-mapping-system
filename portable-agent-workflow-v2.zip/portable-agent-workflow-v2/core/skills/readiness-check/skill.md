# readiness-check

## Portable intent
Assess local, staging, or prod-like readiness and identify blockers.

## Use when
- See portability.json

## Do not use when
- A simpler or narrower skill fully covers the task

## Output
- `readiness-report-v1`
