# test-and-ci-triage

## Portable intent
Analyze test and CI failures and define repair paths.

## Use when
- See portability.json

## Do not use when
- A simpler or narrower skill fully covers the task

## Output
- `ci-triage-report-v1`
