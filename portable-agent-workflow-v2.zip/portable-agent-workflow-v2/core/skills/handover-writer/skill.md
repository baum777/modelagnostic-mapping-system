# handover-writer

## Portable intent
Write structured handovers and executive state summaries.

## Use when
- See portability.json

## Do not use when
- A simpler or narrower skill fully covers the task

## Output
- `handover-spec-v1`
