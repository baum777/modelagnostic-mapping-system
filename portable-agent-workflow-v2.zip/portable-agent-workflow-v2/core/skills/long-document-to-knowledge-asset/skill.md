# long-document-to-knowledge-asset

## Portable intent
Transform long documents into structured knowledge artifacts.

## Use when
- See portability.json

## Do not use when
- A simpler or narrower skill fully covers the task

## Output
- `knowledge-asset-v1`
