# Architecture Spec — Portable Agent Workflow Core v2

## 1. Purpose
This repository is the canonical shared workflow core for agent-capable model providers. Its purpose is to define portable skills, tool contracts, output contracts, eval requirements, and provider adapters for OpenAI/Codex, Claude, Qwen Code, Kimi K2.5, and compatible systems.

## 2. Non-negotiables
- The core must remain provider-neutral.
- Skills must be defined by portable intent, not vendor packaging.
- Provider-specific plugin/extension/template mechanics must not leak into the core contracts.
- All mutating tools must be explicitly classified and approval-gated.
- Output contracts must be versioned and machine-checkable.
- Every provider export must be downstream from the core, never the source of truth.

## 3. Architecture layers
### 3.1 Core
Contains portable skills, tool contracts, output contracts, schemas, eval definitions, and canonical docs.

### 3.2 Provider adapters
Contain packaging rules, provider notes, export mappings, and caveats.

### 3.3 Runtime/tooling layer
Contains MCP-compatible contracts, tool schemas, approval matrixes, and validation scripts.

### 3.4 Eval layer
Contains routing, schema, tool-selection, boundary, provider-parity, and failure-mode evals.

## 4. Primary abstractions
### 4.1 Use-case families
- codebase-work
- repo-governance
- research-synthesis
- long-document-transformation
- structured-deliverables

### 4.2 Skills
Each skill is a portable workflow unit with:
- `skill.md`
- `portability.json`
- `evals.json`
- optional provider projection notes

### 4.3 Tool contracts
Each tool contract defines:
- schema
- side effects
- approval requirement
- provider compatibility
- routing hints
- MCP compatibility

### 4.4 Output contracts
Every non-trivial workflow must emit a named versioned output contract.

## 5. Canonical skill set v1
- repo-audit
- readiness-check
- migration-planner
- research-synthesis
- long-document-to-knowledge-asset
- handover-writer
- tool-contract-auditor
- prompt-system-architect
- checklist-and-bundle-builder
- test-and-ci-triage

## 6. Provider strategy
### OpenAI / Codex
Use `AGENTS.md`, skills, optional subagents, and packaging/export maps.

### Claude
Use skills, custom commands, subagents, hooks, and tool/MCP descriptions.

### Qwen Code
Use extensions, skills, commands, subagents, and MCP where appropriate.

### Kimi K2.5
Use agent templates, tool schemas, JSON-mode outputs, search/tool orchestration, and MCP-compatible designs.

## 7. Migration doctrine
- Preserve repo truth while decoupling provider surfaces.
- Move vendor-specific artifacts behind provider adapters.
- Introduce contracts before large-scale content migration.
- Introduce evals before mass packaging/export automation.

## 8. Release gate
A release is blocked if:
- any core contract is invalid
- any required output schema is broken
- any skill lacks required portability metadata
- any mutating tool lacks approval classification
- any golden eval fails on hard-block conditions
