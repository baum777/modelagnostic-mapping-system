# Target Repository Structure

```text
repo/
  README.md
  docs/
    architecture-spec.md
    repo-target-structure.md
    use-case-to-skill-mapping.md
    portability-matrix.md
    provider-capability-matrix.md
  prompts/
    planning-prompt-gpt5.4-mini.md
    implement-prompt-gpt5.4-mini.md
    final-review-prompt-gpt5.4-mini.md
  contracts/
    schemas/
      portable-skill.schema.json
      output-contract.schema.json
      tool-contract.schema.json
    output-contracts/
      audit-report-v1.json
      readiness-report-v1.json
      migration-plan-v1.json
      research-synthesis-v1.json
      knowledge-asset-v1.json
      handover-spec-v1.json
      tool-audit-v1.json
      prompt-architecture-spec-v1.json
      bundle-spec-v1.json
      ci-triage-report-v1.json
    tool-contracts/
      catalog.json
      approval-matrix.json
  core/
    skills/
      <skill-id>/
        skill.md
        portability.json
        evals.json
  providers/
    openai-codex/
    anthropic-claude/
    qwen-code/
    kimi-k2_5/
  evals/
    routing/
    schema/
    tool-selection/
    boundary/
    provider-parity/
    failure-modes/
  scripts/
    validate-contracts.sh
    export-provider-bundles.sh
```

## Rules
- `core/` is canonical.
- `providers/` must never redefine core intent.
- `contracts/` is canonical for machine-readable truth.
- `prompts/` are operational control surfaces, not source truth.
