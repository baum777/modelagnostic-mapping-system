# Use-Case to Skill Mapping

| Use case | Primary skill | Secondary skills | Output contract |
|---|---|---|---|
| Repo audit & architecture understanding | `repo-audit` | `handover-writer`, `migration-planner` | `audit-report-v1` |
| Readiness / debugging / CI triage | `readiness-check` | `test-and-ci-triage` | `readiness-report-v1` |
| Cross-provider planning / refactor planning | `migration-planner` | `prompt-system-architect` | `migration-plan-v1` |
| Web research / best-practice synthesis | `research-synthesis` | `handover-writer` | `research-synthesis-v1` |
| PDFs / transcripts / long docs | `long-document-to-knowledge-asset` | `checklist-and-bundle-builder` | `knowledge-asset-v1` |
| Structured handovers / executive reports | `handover-writer` | `repo-audit` | `handover-spec-v1` |
| Tool surface / MCP / governance audit | `tool-contract-auditor` | `prompt-system-architect` | `tool-audit-v1` |
| Prompt/skill/agent-system design | `prompt-system-architect` | `migration-planner` | `prompt-architecture-spec-v1` |
| Bundles / checklists / application packs | `checklist-and-bundle-builder` | `long-document-to-knowledge-asset` | `bundle-spec-v1` |
| Test and CI issue triage | `test-and-ci-triage` | `readiness-check` | `ci-triage-report-v1` |
