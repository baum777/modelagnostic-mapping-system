This folder holds eval fixtures and cases for this category.
Hard-block eval failures should be documented explicitly.
